from tkinter import *
import os
from tkinter import filedialog as fd
import numpy as np
from PIL import Image, ImageFilter
from tkinter import messagebox
import uuid
import hashlib
import easygui


desktopDir = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')

def myhash(str):
    firstpart, secondpart = str[:(int)(len(str)/2)], str[(int)(len(str)/2):]
    firstpart = firstpart[::-1]
    secondpart = secondpart[::-1]
    result=""
    for i in range(0,len(firstpart),3):
        result=result+firstpart[i]+secondpart[i]
    #print("my "+result+" str= "+str)
    return result;

def isSecurityCodeTrue():
    try:
        f = open("security.txt", "r")
        first_line = f.readline()
    except:
      return 2
    str2hash = "999"+hex(uuid.getnode())+"666"
    result = hashlib.md5(str2hash.encode())
    newhash=myhash(result.hexdigest())
    if newhash == first_line:
        return 1
    else:
        return 0


class Mainwindow:
   files = []
   fileCount = ""
   def __init__(self,root2):
       self.root = root2
       (self.root).configure(background='silver')
       (self.root).title("Crop eShram as Card")
       (self.root).geometry("400x300+440+200")
       (self.root).iconbitmap("myicon.ico")
       # Add a Label widget
       label1 = Label((self.root), text=" Crop eShram ", font=('Georgia 20'))
       label1.pack(pady=2)
       (self.root).resizable(FALSE, FALSE)
       label2 = Label((self.root), text=" Only PNG Image Allowed ", font=('Georgia 10'))
       # label.pack(side=LEFT,padx=10,pady=5)
       label2.place(x=30, y=130)
       self.files = []
       self.fileCount = StringVar()
       filesSelected = Label((self.root), textvariable=self.fileCount, fg='green', font=(("Times New Roman"), 13))
       filesSelected.place(x=300, y=130)
       self.fileCount.set(str(len(self.files)) + " files")
       btn = Button((self.root), text='Choose File', bg='yellow', fg="black", highlightbackground="black",
                    highlightthickness=4, bd=4, activebackground='green', command=self.select_files,
                    font=(("Times New Roman"), 10))
       btn.place(x=200, y=130)
       convert = Button((self.root), text='Convert', bg='orange', fg="black", highlightbackground="black",
                        highlightthickness=4, bd=4, activebackground='green', command=self.start,
                        font=(("Times New Roman"), 10))
       # Set a relative position of button
       convert.place(x=200, y=170)
       self.root.btn=btn
       self.root.convert = convert
       (self.root).mainloop()

   def updateFileCount(self):
       (self.fileCount).set(str(len(self.files)) + " files")

   def select_files(self):
        self.files = []
        filetypes = (
            ('PNG Images', '*.png'),
            ('ALL files', '*.*')
        )
        filenames = fd.askopenfilenames(
            title='Select only PNG files',
            initialdir=desktopDir,
            filetypes=filetypes)
        self.files = filenames
        self.updateFileCount()

   def start(self):
        self.root.convert["text"] = "Processing..."
        self.root.convert["state"] = "disabled"
        self.root.btn["state"] = "disabled"
        status = -1
        for i in self.files:
            status = self.convertAndSave(i)
            if status == 1:
                pass
            else:
                messagebox.showerror("Error occurred !!!", "Only eShram card Images allowed !")
        self.root.convert["state"] = "normal"
        self.root.convert["text"] = "Convert"
        self.root.btn["state"] = "normal"
        self.files = []
        self.updateFileCount()
        return 1

   def convertAndSave(self,file):
       dir, filename = os.path.split(file)
       filename, extension = os.path.splitext(filename)
       try:
           im = Image.open(file).convert('RGB')
          # print(file)
           na = np.array(im)
           orig = na.copy()  # Save original
           # Median filter to remove outliers
           im = im.filter(ImageFilter.MedianFilter(3))
           Y, X = np.where(np.all(na == [241, 241, 241], axis=2))
           top, bottom = Y[0], Y[-1]
           left, right = X[0], X[-1]
           print(top, bottom, left, right)

           diff = top
           flag = 0
           top1 = top
           bottom1 = bottom
           top2 = top
           bottom2 = bottom
           white = [255, 255, 255]
           blue = [241, 241, 241]
           while diff < bottom:
               diff = diff + 1
               # print(diff,na[diff][left])
               if np.array_equal(na[diff][left], white) and flag == 0:
                   bottom1 = diff
                   flag = flag + 1
               if np.array_equal(na[diff][left], blue) and flag > 0:
                   top2 = diff
                   break
           print(bottom1, top2)
           # Extract Region of Interest from unblurred original
           ROI1 = orig[top1:bottom1, left:right]
           # result = Image.fromarray(ROI1)
           Image.fromarray(ROI1).save(desktopDir + "/" + filename + "_1" + extension)

           # Extract Region of Interest from unblurred original
           ROI2 = orig[top2:bottom2, left:right]
           # result = Image.fromarray(ROI2)

           Image.fromarray(ROI2).save(desktopDir + "/" + filename + "_2" + extension)
       except:
           print("error")
           return 0
       else:
           return 1


class Activation:
    def __init__(self,root):
        self.root =root
        (self.root).configure(background='silver')
        (self.root).title("Activate Software")
        (self.root).geometry("400x210+475+250")
        (self.root).iconbitmap("myicon.ico")
        (self.root).resizable(FALSE, FALSE)
        # Add a Label widget
        label1 = Label((self.root), text=" Crop eShram ", font=('Georgia 20'))
        label1.pack(pady=2)
        label2 = Label((self.root), text="Hint : Run as administrator then enter Activation code.", bg="silver",
                       font=(('Georgia 10'), 8))
        # label.pack(side=LEFT,padx=10,pady=5)
        label2.place(x=50, y=48)

        macaddress = Text((self.root), bg='orange', fg="black", bd=2, height=1, width=16, font=(('Times New Roman'), 11))
        macaddress.place(x=20, y=180)
        macaddress.insert(INSERT, "" + (hex(uuid.getnode())))
        macaddress.configure(state='disabled')

        label3 = Label((self.root), text="Activation Code :", bg="silver", font=(('Times New Roman'), 10))
        label3.place(x=20, y=80)

        activationCode = Text((self.root), bg='white', fg="black", bd=2, height=1, width=35, font=(('Times New Roman'), 11), )
        activationCode.place(x=20, y=100)

        activate = Button((self.root), text='Submit', bg='yellow', fg="black", highlightbackground="black",
                          highlightthickness=2, bd=1, activebackground='green', font=(("Times New Roman"), 10),command=self.callSubmit)

        activate.place(x=280, y=100)
        (self.root).val=activationCode
        (self.root).mainloop()
        pass

    def callSubmit(self):
        str=((self.root).val).get("1.0",'end-1c')
        if str == "":
            messagebox.showinfo("Information!", "Enter Activation code")
        else:
            str=str.strip() # trimming string remove left and right white spaces
            self.submit(str)

    def submit(self,code):
        try:
            f = open("security.txt", "w+")
            f.write(str(code))
            f.close()
        except:
            messagebox.showwarning("Warning!", "Run as administrator and then enter security code!")
            return
        j = isSecurityCodeTrue()
        if j == 2:
            sys.exit("0")  # message already displayed in issecuritytrue function
        elif j == 1:
            messagebox.showinfo("Activation Success!",
                                "Congratulations! \n Activation code accepted!\n Please Restart Application!")
            sys.exit("0")
            return
        else:
            messagebox.showerror("Activation Failed!",
                                 "Wrong Activation Code! \n \n Contact : gate2021.vivek@gmail.com")
            return


def main():
    root = Tk()
    i=isSecurityCodeTrue()
    if i == 2:
        root.withdraw()
        messagebox.showinfo("Error Missing Files!", "Some Files are Missing \n\n  Reinstall Software!")
        sys.exit("0")
    else:
        if i == 0:
          acti = Activation(root)
        else:
          mainW= Mainwindow(root)

main()